# Quick Reference Guide - Advanced Python Concepts

## Table of Contents
1. [OOP Concepts](#oop-concepts)
2. [Design Patterns](#design-patterns)
3. [Type Hints](#type-hints)
4. [Decorators](#decorators)
5. [Magic Methods](#magic-methods)
6. [Advanced Features](#advanced-features)

---

## OOP Concepts

### Abstract Base Classes (ABC)
```python
from abc import ABC, abstractmethod

class Animal(ABC):
    @abstractmethod
    def make_sound(self):
        pass

class Dog(Animal):
    def make_sound(self):
        return "Woof!"
```

### Properties
```python
class Person:
    def __init__(self, name):
        self._name = name
    
    @property
    def name(self):
        return self._name
    
    @name.setter
    def name(self, value):
        self._name = value
    
    @property
    def name_upper(self):
        return self._name.upper()
```

### Class Methods vs Static Methods
```python
class MyClass:
    @classmethod
    def from_string(cls, string):
        # Has access to cls
        return cls(string)
    
    @staticmethod
    def utility_function(x):
        # No access to cls or self
        return x * 2
```

---

## Design Patterns

### 1. Singleton Pattern
```python
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
```

### 2. Factory Pattern
```python
class AnimalFactory:
    @staticmethod
    def create_animal(animal_type):
        animals = {
            'dog': Dog,
            'cat': Cat
        }
        return animals[animal_type]()
```

### 3. Strategy Pattern
```python
class Context:
    def __init__(self, strategy):
        self._strategy = strategy
    
    def execute_strategy(self):
        return self._strategy.execute()

class ConcreteStrategyA:
    def execute(self):
        return "Strategy A"

class ConcreteStrategyB:
    def execute(self):
        return "Strategy B"
```

### 4. Observer Pattern
```python
class Subject:
    def __init__(self):
        self._observers = []
    
    def attach(self, observer):
        self._observers.append(observer)
    
    def notify(self):
        for observer in self._observers:
            observer.update(self)
```

---

## Type Hints

### Basic Types
```python
def greet(name: str) -> str:
    return f"Hello, {name}"

age: int = 25
price: float = 19.99
is_active: bool = True
```

### Collections
```python
from typing import List, Dict, Set, Tuple

names: List[str] = ["Alice", "Bob"]
scores: Dict[str, int] = {"Alice": 100}
unique_ids: Set[int] = {1, 2, 3}
coordinate: Tuple[float, float] = (10.5, 20.3)
```

### Optional and Union
```python
from typing import Optional, Union

def find_user(id: int) -> Optional[User]:
    # Returns User or None
    pass

def process(value: Union[int, str]) -> bool:
    # Accepts int or str
    pass
```

### Callable
```python
from typing import Callable

def apply(func: Callable[[int], int], value: int) -> int:
    return func(value)
```

### Protocols (Structural Typing)
```python
from typing import Protocol

class Drawable(Protocol):
    def draw(self) -> None:
        ...

def render(obj: Drawable) -> None:
    obj.draw()  # Any object with draw() method works
```

---

## Decorators

### Basic Decorator
```python
def my_decorator(func):
    def wrapper(*args, **kwargs):
        print("Before function")
        result = func(*args, **kwargs)
        print("After function")
        return result
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")
```

### Decorator with Arguments
```python
def repeat(times):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(3)
def greet():
    print("Hello!")
```

### Using functools.wraps
```python
from functools import wraps

def my_decorator(func):
    @wraps(func)  # Preserves function metadata
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper
```

### Class Decorators
```python
def singleton(cls):
    instances = {}
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return get_instance

@singleton
class Database:
    pass
```

---

## Magic Methods

### Object Creation and Representation
```python
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __repr__(self):
        return f"Point({self.x}, {self.y})"
    
    def __str__(self):
        return f"({self.x}, {self.y})"
```

### Comparison Operators
```python
class Person:
    def __eq__(self, other):
        return self.age == other.age
    
    def __lt__(self, other):
        return self.age < other.age
    
    def __le__(self, other):
        return self.age <= other.age
```

### Arithmetic Operators
```python
class Vector:
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    
    def __mul__(self, scalar):
        return Vector(self.x * scalar, self.y * scalar)
```

### Container Methods
```python
class CustomList:
    def __len__(self):
        return len(self.items)
    
    def __getitem__(self, index):
        return self.items[index]
    
    def __setitem__(self, index, value):
        self.items[index] = value
    
    def __contains__(self, item):
        return item in self.items
```

### Context Manager
```python
class FileManager:
    def __enter__(self):
        self.file = open('file.txt', 'w')
        return self.file
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.file.close()
        return False

with FileManager() as f:
    f.write("Hello")
```

### Callable Objects
```python
class Multiplier:
    def __init__(self, factor):
        self.factor = factor
    
    def __call__(self, x):
        return x * self.factor

double = Multiplier(2)
print(double(5))  # 10
```

---

## Advanced Features

### Dataclasses
```python
from dataclasses import dataclass, field

@dataclass
class Product:
    name: str
    price: float
    tags: list = field(default_factory=list)
    
    def __post_init__(self):
        # Called after __init__
        self.price = round(self.price, 2)
```

### Enums
```python
from enum import Enum, auto

class Color(Enum):
    RED = 1
    GREEN = 2
    BLUE = 3

class Status(Enum):
    PENDING = auto()
    APPROVED = auto()
    REJECTED = auto()

# Enhanced Enum
class Direction(Enum):
    NORTH = (0, 1)
    SOUTH = (0, -1)
    EAST = (1, 0)
    WEST = (-1, 0)
    
    def __init__(self, dx, dy):
        self.dx = dx
        self.dy = dy
```

### Context Managers (contextlib)
```python
from contextlib import contextmanager

@contextmanager
def timer():
    import time
    start = time.time()
    yield
    end = time.time()
    print(f"Elapsed: {end - start:.2f}s")

with timer():
    # Code to time
    pass
```

### Generators
```python
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

for num in fibonacci(10):
    print(num)
```

### List/Dict Comprehensions
```python
# List comprehension
squares = [x**2 for x in range(10)]
evens = [x for x in range(20) if x % 2 == 0]

# Dict comprehension
square_dict = {x: x**2 for x in range(5)}

# Set comprehension
unique_lengths = {len(word) for word in ['cat', 'dog', 'bird']}

# Generator expression
sum_of_squares = sum(x**2 for x in range(1000000))
```

### Lambda Functions
```python
square = lambda x: x**2
add = lambda x, y: x + y

# With sorted
people.sort(key=lambda p: p.age)

# With filter
evens = list(filter(lambda x: x % 2 == 0, numbers))

# With map
squared = list(map(lambda x: x**2, numbers))
```

### Partial Functions
```python
from functools import partial

def power(base, exponent):
    return base ** exponent

square = partial(power, exponent=2)
cube = partial(power, exponent=3)

print(square(5))  # 25
print(cube(5))    # 125
```

### NamedTuples
```python
from collections import namedtuple

Point = namedtuple('Point', ['x', 'y'])
p = Point(10, 20)
print(p.x, p.y)  # 10 20
```

### DefaultDict and Counter
```python
from collections import defaultdict, Counter

# DefaultDict
word_count = defaultdict(int)
word_count['hello'] += 1  # No KeyError

# Counter
letters = Counter('hello world')
print(letters.most_common(3))
```

---

## Error Handling

### Custom Exceptions
```python
class ValidationError(Exception):
    def __init__(self, field, message):
        self.field = field
        super().__init__(message)

raise ValidationError('email', 'Invalid email format')
```

### Context Manager for Errors
```python
try:
    risky_operation()
except ValueError as e:
    print(f"Value error: {e}")
except KeyError as e:
    print(f"Key error: {e}")
except Exception as e:
    print(f"Unexpected error: {e}")
else:
    print("No errors!")
finally:
    print("Always executed")
```

---

## Best Practices

### 1. Type Hints Everywhere
```python
def process_data(data: List[Dict[str, Any]]) -> Optional[DataFrame]:
    pass
```

### 2. Use Dataclasses for Data Containers
```python
@dataclass
class User:
    name: str
    age: int
    email: str
```

### 3. Prefer Composition Over Inheritance
```python
class Car:
    def __init__(self):
        self.engine = Engine()  # Composition
        self.wheels = [Wheel() for _ in range(4)]
```

### 4. Use Context Managers
```python
with open('file.txt') as f:
    data = f.read()
```

### 5. List Comprehensions for Readability
```python
# Good
squares = [x**2 for x in range(10)]

# Avoid
squares = []
for x in range(10):
    squares.append(x**2)
```

---

## Testing Concepts

### Basic Unit Test
```python
import unittest

class TestMath(unittest.TestCase):
    def test_addition(self):
        self.assertEqual(1 + 1, 2)
    
    def test_division(self):
        with self.assertRaises(ZeroDivisionError):
            1 / 0
```

### Mocking
```python
from unittest.mock import Mock, patch

@patch('module.function')
def test_with_mock(mock_func):
    mock_func.return_value = 42
    result = my_function()
    self.assertEqual(result, 42)
```

---

This reference guide covers the essential advanced Python concepts used in professional development!
